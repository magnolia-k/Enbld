#include "config.h"

int main() {
	func();
	return 0;
}
