#include "config.h"
#include <stdio.h>

void func() {
	puts(PACKAGE_STRING);
}
